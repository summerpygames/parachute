from olpcgames import activity
from gettext import gettext as _

class Activity(activity.PyGameActivity):
    """Your Sugar activity"""
    
    game_name = 'run'
    game_title = _('Mind The Gap')
    game_size = None
