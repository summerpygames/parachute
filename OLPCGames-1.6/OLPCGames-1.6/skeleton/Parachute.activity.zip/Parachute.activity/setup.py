#!/usr/bin/env python
from sugar.activity import bundlebuilder
if __name__ == "__main__":
    bundlebuilder.start("Parachute")
